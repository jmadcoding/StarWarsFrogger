/*
    canvas-events.js
*/

//-----------------------------------------------------------
//When the page has fully loaded, execute the eventWindowLoaded function
window.addEventListener("load", eventWindowLoaded, false);
//-----------------------------------------------------------

//-----------------------------------------------------------
//eventWindowLoaded()
//Called when the window has been loaded it then calls the canvasapp() 
function eventWindowLoaded() {
    canvasApp();	
} // eventWindowLoaded()
//-----------------------------------------------------------

//-----------------------------------------------------------
//canvasSupport() 
//Check for Canvas Support using modernizr.js
function canvasSupport() {
    return Modernizr.canvas;	
} // canvasSupport()
//-----------------------------------------------------------

//----------------------------------------------------------
//canvasApp() 
//The function where ALL our canvas code will go
function canvasApp() {

    //-----------------------------------------------------------
    //Check to see if the canvas has a context 
    if (!canvasSupport()) {
        return;	//Canvas not supported so exit the function
    }
    
/* --------------------------------------------------------- */
/* Math Utility Fuctions */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    //get a random number with in a range	
    function getRandom(min, max) {
        return Math.floor( Math.random() * (max - min) + min );
    }//getRandom()
    
/* --------------------------------------------------------- */
/* Image Utility Functions */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    // create and load image objects into an array based on an image source array
    function loadImages( images, imageSources, callback ) {
        var loadedImages = 0;
        
        //- - - - - - - - - - - - - - - - - - - - -
        // for each imageSource
        for ( var src = 0; src < imageSources.length; src++ ) {

            //- - - - - - - - - - - - - - - - - - - - -
            //create a new image object
            images[src] = new Image();
            
            //- - - - - - - - - - - - - - - - - - - - -
            //load the image 
            images[src].onload = function() {
                if( ++loadedImages >= imageSources.length ) {
                    callback( images );
                }; //if
            } //onload()
            
            //- - - - - - - - - - - - - - - - - - - - -
            //set the image source
            images[src].src = imageSources[src];
            
        } //for
        
      } //loadimages()

/* --------------------------------------------------------- */
/* Canvas Variables */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
        
    //-----------------------------------------------------------
    //Setup the canvas object
    var theCanvas = document.getElementById("myCanvas"); //get the canvas element
    var canvasHeight = theCanvas.height; //get the heigth of the canvas
    var canvasWidth = theCanvas.width;  //get the width of the canvas
    var context = theCanvas.getContext("2d");  //get the context
    var canvasColor = "black";  //canvas bg color

/* --------------------------------------------------------- */
/* Image Variables */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
    
    //-----------------------------------------------------------
    // game control
    var gameOver = false;
    
    //-----------------------------------------------------------
    // declare variable to count the frames
    
    var frameCounter = 0;
    var frameInterval = 10;
    
    //-----------------------------------------------------------
    // declare an array to hold the image objects
    var images = [];
    
    //-----------------------------------------------------------
    // declare an array for image sources and assign the image sources
    var imageSources = [
        // ship image
        "./images/xwing.png",
        // asteriod image
        "./images/asteroid.png",
        // background image
        "./images/stardestroyerbg.jpg"
    ]; //imageSource    

    //-----------------------------------------------------------
    // Image Location Variables
    var shipIndex = 0;      //define the index of the ship image in the array
    var ateriodIndex = 1;   //define the index of the asteriod image in the array
    var bgIndex = 2;        //define the index of the BG image in the array
   
/* --------------------------------------------------------- */
/* Object Variables */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
        
    //-----------------------------------------------------------
    //Setup the ship paramaters
    
    //dimensions of the ship
    var shipHeight = parseInt( 400/8 );             
    var shipWidth = parseInt( 470/8 );

    //speed of movement
    var shipSpeed = parseInt( shipWidth * 0.1 );
    
    //position of ship
    var shipMargin = 0;
    var shipX = 10;      
    var shipY = 235;  

    var column0X = 0;
    var column1X = 100;
    var column2X = 200;
    var column3X = 300;
    var column4X = 400;
    var column5X = 500;
    var column6X = 600;
    var column7X = 700;
    var column8X = 800;
    
    var boxX = 750;
    var boxY = 0;
    var boxHeight = 500;
    var boxWidth = 50;
    
    //-----------------------------------------------------------
    // Asteriod Location Variables
    
    //define arrays to hold the location of each asteriod
    var asteroidX = [];
    var asteroidY = [];

    //dimensions of the asteriods
    var asteroidActualWidth = 418;             
    var asteroidActualHeight = 474;    
    //define the min and max bounding values for the size of the asteriods
    var asteriodMaxSize = 10;
    var asteriodMinSize = 20;
    //define an array to hold the size of each asteriod
    var asteroidWidth = [];
    var asteroidHeight = [];

    //define arrays to hold the direction of movement for each asteriod
    var asteroidMoveX = [];
    var asteroidMoveY = [];

    //define the min and max boundaries for moving the asteriods
    var asteriodMinSpeed = 5;
    var asteriodMaxSpeed = 5;
    //define an array to hold the speed of each asteriod
    var asteroidSpeed = [];
    
    //-----------------------------------------------------------
    // Key Press Variables
    
    //keys pressed
	var keys = [];
    
    //key pressed values
    var LeftArrowKey = 37;
    var RightArrowKey = 39;
    var UpArrowKey = 38;
    var DownArrowKey = 40;
/* --------------------------------------------------------- */
/* Ship Functions */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */     
   
    //-----------------------------------------------------------
    //function to move the ship
    function moveShip() {
        
        //move the ship 
        if ( keys[ LeftArrowKey ] ) { //left arrow key

            //move ship LEFT
            shipX -= shipSpeed;   
            
            //check the left border
            if ( shipX < 0 )
                shipX = 0;
            
        } else if ( keys[ RightArrowKey ] ) { //right arrow key

            //move ship RIGHT
            shipX += shipSpeed;   

            //check the right border
            if ( shipX >= canvasWidth-shipWidth )
                shipX = canvasWidth-shipWidth;
        
        } else if ( keys[ UpArrowKey ] ) { //right arrow key

            //move ship UP
            shipY -= shipSpeed;   

            //check the TOP border
            if ( shipY < 0 )
                shipY = 0;
       
        } else if ( keys[ DownArrowKey ] ) { //right arrow key

            //move ship DOWN
            shipY += shipSpeed;   

            //check the BOTTOM border
            if ( shipY >= canvasHeight-shipHeight )
                shipY = canvasHeight-shipHeight;
        }
        // else if 
                
    }//moveShip()

    //-----------------------------------------------------------
    //function to destroy the ship 
    
    function endGame() {
                
        //--------------------------------------------
        //set the game over
        gameOver = true;
        drawGameOver();

    }//endGame()
            
/* --------------------------------------------------------- */
/* Asteriod Functions */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */     
   
    //-----------------------------------------------------------
    //function to generate random starts for asteriods
    function generateAsteriods( numAsteriods ) {
                    
        //generate numAsteriods
        for ( var i = 0; i < numAsteriods; i++ ) {
            
            //console.log( "generateAsteriods(): " + i );

            //--------------------------------------------
            // get a next Size
            var nextSize = getRandom( asteriodMinSize, asteriodMaxSize );
            var rand = getRandom(1, 9);
            // push the next W and H
            asteroidWidth.push(  parseInt(asteroidActualWidth / nextSize) ); 
            asteroidHeight.push(  parseInt(asteroidActualHeight / nextSize) ); 
            
            //--------------------------------------------
            // get a next X and Y starting location
            // x can be anywhere along the top
            var nextX = getRandom( 0, canvasWidth - parseInt(asteroidActualWidth / nextSize) );
            // y can be on the top half
            //var nextY = getRandom( 0, parseInt(canvasHeight/3) );
            var nextY = 0;
            
            //--------------------------------------------
            // get the next speed
            var nextSpeed = getRandom( asteriodMinSpeed, asteriodMaxSpeed );
            
            
            if ( rand == 1 )
                    asteroidX.push(column1X);    
            else if ( rand == 2 ){
                    asteroidX.push(column2X);  
                    nextY = canvasHeight;
                    nextSpeed = nextSpeed*-1;
            }
            else if ( rand == 3 )
                    asteroidX.push(column3X);
            else if ( rand == 4 ){
                    asteroidX.push(column4X);
                    nextY = canvasHeight;
                    nextSpeed = nextSpeed*-1;
            }
            else if ( rand == 5 )
                    asteroidX.push(column5X);        
            else if ( rand == 6 ){
                    asteroidX.push(column6X);
                    nextY = canvasHeight;
                    nextSpeed = nextSpeed*-1;
            }
            else if ( rand == 7 )
                    asteroidX.push(column7X);
            else if ( rand == 8 ){
                    asteroidX.push(column8X);
                    nextY = canvasHeight;
                    nextSpeed = nextSpeed*-1;
            }
            else if ( rand == 9 )
                    asteroidX.push(column0X);
            
            
            // push the next X and Y
            //asteroidX.push(nextX); 
            asteroidY.push(nextY); 
                                
            
            //console.log( "nextSpeed: " + nextSpeed );
            // set the next speed -- we really only use Y to move
            asteroidMoveX.push(nextSpeed);
            asteroidMoveY.push(nextSpeed);
            
        } // for numAsteriods
        
    } //generateAsteriods()

    //-----------------------------------------------------------
    // function to move all the asteriods inside the dimensions of the canvas
    function moveAsteriods( numAsteriods ) {

        //--------------------------------------------
        //for each numAsteroids
        for ( var i = 0; i < numAsteriods; i++ ) {

            //--------------------------------------------
            // increment to the next location based on movement size
            asteroidY[i] = asteroidY[i] + asteroidMoveY[i];

            //--------------------------------------------
            // at the bottom of the screen
            if ( asteroidY[i] > canvasHeight ) {

                //--------------------------------------------
                //destroy this asteriod     
                
                destroyAsteroid( i );
     
                //--------------------------------------------
                //add a new asteriod
                generateAsteriods( 1 );
                
            } //if asteroidY
            
        } //for numAsteriods

    } //moveAsteriods() 

    //-----------------------------------------------------------
    //destroy an Asteroid   
    
    function destroyAsteroid( i ) {
        
        //--------------------------------------------
        //remove the i'th asteriod from the asteriod array set        
        asteroidWidth.splice(i, 1);
        asteroidHeight.splice(i, 1);

        asteroidX.splice(i, 1);
        asteroidY.splice(i, 1);

        asteroidMoveX.splice(i, 1);
        asteroidMoveY.splice(i, 1);
        
        asteroidSpeed.splice(i, 1);

    }//destroyAsteroid()
    
    //-----------------------------------------------------------
    //add an Asteroid    
    function addAsteroid( i ) {
        
        //--------------------------------------------
        //add an asteriod based on the interval     
        if ( ( frameCounter %  frameInterval ) === 0 ) {
            
            console.log( "addAsteriod() : " + frameCounter );

            //add a new asteriod
            generateAsteriods( 1 );
            
        }//if
            
    }//addAsteroid()

/* --------------------------------------------------------- */
/* Event Handlers */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
	
    //-----------------------------------------------------------
    //event listeners
    
	//When a key is pressed set its keycode to true (pressed)
	window.addEventListener("keydown", function (e) {
		keys[e.keyCode] = true;
	});
	
    //When a pressed key is released set its keycode to false (not pressed)
	window.addEventListener("keyup", function (e) {
		keys[e.keyCode] = false;
	});
    
    //key event listenter
    window.addEventListener( "keydown", eventKeyDown, true );
    
    
    //-----------------------------------------------------------
    //event handler for key down
    function eventKeyDown( e ) {
        
        //--------------------------------------------
        //get the key pressed
        var keyPressed = String.fromCharCode(e.keyCode);
        //console.log( e.keyCode + " : " + keyPressed );
        
        //--------------------------------------------
        //check to see if a new laser has been fired
        if ( keyPressed == " " ) {
            fireLaser();
        } // if
        
    } //eventKeyDown()
        
/* --------------------------------------------------------- */
/* Draw Image Functions */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    //-----------------------------------------------------------
    // draw the BG Image
    function drawBGImage() {
        
        //draw the bg image to fill the canvas
        context.drawImage (images[bgIndex], 0, 0, canvasWidth, canvasHeight);
        
    } //drawBGImage
    
    //-----------------------------------------------------------
    // draw the ship
    function drawShip() {
        
        //console.log("drawShip(): " + shipX + ":" + shipY );
        //draw the ship
        context.drawImage (images[shipIndex], shipX, shipY, shipWidth, shipHeight);     
        
    }//drawShip()

    //-----------------------------------------------------------
    // draw the asteriod
    function drawAsteriod( numAsteriods ) {
        
        //for each asteriod
        for ( var i = 0; i < numAsteriods; i++ ) {
            
            //console.log("drawAsteriod[" + i + "]" + asteroidX[i] + ":" + asteroidY[i] );
            //draw the asteriod
            /*context.fillStyle = "white";
            context.fillRect(asteroidX[i], asteroidY[i], asteroidWidth[i], asteroidHeight[i]);
            */
            context.drawImage( images[ateriodIndex], asteroidX[i], asteroidY[i], asteroidWidth[i], asteroidHeight[i] );
            
            
        }//for numAsteriods
        
    }//drawAsteriod()
    
    
    //draw finishing box
       
     function drawBox() {   
    
        //define a rectangle border
        context.beginPath();
        //define our rectangle
        context.rect(747,1,50,498);

        //close path and stroke
        context.closePath();
        context.strokeStyle = "white";
        context.lineWidth = 5;
        context.stroke();
         
        context.font="30px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('F', 764, 105);
         
        context.font="30px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('I', 768, 165);
        
        context.font="30px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('N', 762, 225);
         
        context.font="30px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('I', 768, 285);
         
        context.font="30px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('S', 764, 345);
         
        context.font="30px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('H', 762, 405);
           
     }
    
/* ----------------------------------------------------- */
// Check Collision Functions
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - -*/  
    //-----------------------------------------------------------
    //check collisions between ship and array of asteriods
    /*
        Bounding box collision detection between laser and asteriods.
        For this we need x, y, h, w for each object.
        Set the ship as object1.
        Loop and set each of the asteriods as object2.
    */
    function checkCollisionShip() {

        //--------------------------------------------
        //setup object1 dimensions = the ship
        var o1X = shipX;
        var o1Y = shipY;
        var o1W = shipWidth;
        var o1H = shipHeight;
        
        //--------------------------------------------
        //for each asteriod 
        for ( var i=0; i < asteroidX.length; i++ ) {

            //--------------------------------------------
            //setup object2 dimensions = the asteriod[i]
            var o2X = asteroidX[i];
            var o2Y = asteroidY[i];
            var o2W = asteroidWidth[i];
            var o2H = asteroidHeight[i];

            //--------------------------------------------
            //check if the laser is in contact with the asteriod
            if (   o1X < o2X + o2W 
                && o1X + o1W > o2X 
                && o1Y < o2Y + o2H 
                && o1Y + o1H > o2Y ) 
            {
                //write out the object locations for debugging
                //console.log( "collision: " +
                //            "o1 "+o1X+":"+o1Y+":"+o1W+":"+o1H+" "+
                //"o2 "+o2X+":"+o2Y+":"+o2W+":"+o2H+" " );

                //--------------------------------------------
                //end game
      
                endGame();
                
            } //if collision
            
            var o3X = boxX;
            var o3Y = boxY;
            var o3W = boxWidth;
            var o3H = boxHeight;
            
            if (   o1X < o3X + o3W 
                && o1X + o1W > o3X 
                && o1Y < o3Y + o3H 
                && o1Y + o1H > o3Y ) 
                
            {
                displayVictory();
            }
            
        } //for each asteriod
  
    } //checkCollisionShip()
        

/* --------------------------------------------------------- */
/* Clear and Draw Canvas Functions */
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

    function drawGameOver() {
        
        //set the font
        context.font="50px Play";
        context.strokeStyle = "white";
        context.fillStyle = "black";
        context.strokeText('YOU LOSE', 285, 200);
        
    }//drawGameOver()
    
    function displayVictory() {
        
        context.font="50px Play";
        
        context.strokeText('VICTORY', 290, 280);
        context.strokeStyle = "white";
        context.fillStyle = "black";
        gameOver = true;
    }
    
    //-----------------------------------------------------------
    // clear canvas
    function clearCanvas( canvasColor ) { 
        //set the fill color
        context.fillStyle = canvasColor;
        //fill the whole canvas
        context.fillRect(0, 0, canvasWidth , canvasHeight);
    } //  clearCanvas()
            
    //-----------------------------------------------------------
    //draw the canvas
    function drawCanvas() {
        
        //--------------------------------------------
        //1. clear the canvas
        
        //clear the canvas
        clearCanvas( canvasColor );
        //draw the bg image
        drawBGImage();
        //increment the frame counter
        frameCounter++;


        //--------------------------------------------
        //2. move objects
        //move the asteriods
        moveAsteriods( asteroidX.length);
        //move the ship
        moveShip();
        //add asteriods
        addAsteroid();
        
        //--------------------------------------------
        //3.  check for collisions
        
        //check for collision between ship and asteriods and ship and end box
        checkCollisionShip();
   
        //--------------------------------------------
        //4. draw objects
        
        //draw the ship
        drawShip();
        //draw the asteriods
        drawAsteriod( asteroidX.length );
        //draw box
        drawBox();

    } //drawCanvas()

/* --------------------------------------------------------- */
// Game Loop and Setup
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
    
    //-----------------------------------------------------------
    // the game loop
    function gameLoop() {
            
        //draw the canvas
        if ( !gameOver ) {
            requestAnimationFrame( gameLoop );
        }

        drawCanvas();
    } // gameLoop()

    //-----------------------------------------------------------
    //Setup and then call game loop
    
    //generate the first asteriod
    generateAsteriods( 1 );

    //load the images and then call gameLoop()
    loadImages( images, imageSources, function(images) {         
        
        //message so we know the images loaded 
        console.log( "images loaded");
        
        //call game loop
        gameLoop();
        
    });    

} //canvasApp()
//-----------------------------------------------------------
